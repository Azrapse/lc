<?php
	class Configuration extends AppModel 
	{    
		var $name = 'Configuration';
	}
?>
