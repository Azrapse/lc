<?php
	class LocalizedText extends AppModel 
	{    
		var $name = 'LocalizedText';                
		var $displayField = 'message';		
	}
?>
