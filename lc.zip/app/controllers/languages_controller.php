<?php
class LanguagesController extends AppController {
        var $scaffold;
	var $name = 'Languages';
}
?>