<?php
class TranslationsController extends AppController {
        var $scaffold;
	var $name = 'Translations';
}
?>